package com.library.controller;

import com.library.MainApp;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Simple demo credentials for the librarian account.
        if ("admin".equals(username) && "admin".equals(password)) {
            try {
                MainApp.switchScene("dashboard.fxml", 700, 480);
            } catch (IOException e) {
                messageLabel.setText("Error loading dashboard.");
            }
        } else {
            messageLabel.setText("Invalid username or password.");
        }
    }
}
