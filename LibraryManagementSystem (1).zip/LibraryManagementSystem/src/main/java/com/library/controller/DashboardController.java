package com.library.controller;

import com.library.MainApp;
import com.library.service.Library;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.IOException;

public class DashboardController {

    @FXML private Label summaryLabel;

    @FXML
    public void initialize() {
        Library library = Library.getInstance();
        summaryLabel.setText(
                "Books in catalog: " + library.getBooks().size()
                        + "   |   Registered members: " + library.getMembers().size()
        );
    }

    @FXML
    public void openBooks() throws IOException {
        MainApp.switchScene("books.fxml", 720, 480);
    }

    @FXML
    public void openMembers() throws IOException {
        MainApp.switchScene("members.fxml", 720, 480);
    }

    @FXML
    public void logout() throws IOException {
        MainApp.switchScene("login.fxml", 480, 320);
    }
}
