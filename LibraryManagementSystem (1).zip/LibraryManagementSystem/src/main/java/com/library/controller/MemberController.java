package com.library.controller;

import com.library.MainApp;
import com.library.model.Book;
import com.library.model.Member;
import com.library.service.Library;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.Optional;

public class MemberController {

    @FXML private TableView<Member> membersTable;
    @FXML private TableColumn<Member, String> idColumn;
    @FXML private TableColumn<Member, String> nameColumn;
    @FXML private TableColumn<Member, String> emailColumn;
    @FXML private TableColumn<Member, Integer> borrowedColumn;

    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField emailField;
    @FXML private TextField isbnField;
    @FXML private Label messageLabel;

    private final Library library = Library.getInstance();
    private ObservableList<Member> memberData;

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        borrowedColumn.setCellValueFactory(new PropertyValueFactory<>("borrowedCount"));

        refreshTable();
    }

    private void refreshTable() {
        memberData = FXCollections.observableArrayList(library.getMembers());
        membersTable.setItems(memberData);
        membersTable.refresh();
    }

    @FXML
    public void handleAddMember() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || email.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        library.addMember(new Member(id, name, email));
        refreshTable();
        idField.clear();
        nameField.clear();
        emailField.clear();
        messageLabel.setText("Member added.");
    }

    @FXML
    public void handleRemoveSelected() {
        Member selected = membersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("Select a member to remove.");
            return;
        }
        library.removeMember(selected.getId());
        refreshTable();
        messageLabel.setText("Member removed.");
    }

    @FXML
    public void handleBorrow() {
        Member selected = membersTable.getSelectionModel().getSelectedItem();
        String isbn = isbnField.getText().trim();

        if (selected == null) {
            messageLabel.setText("Select a member first.");
            return;
        }
        Optional<Book> bookOpt = library.findBookByIsbn(isbn);
        if (bookOpt.isEmpty()) {
            messageLabel.setText("No book with that ISBN.");
            return;
        }
        boolean success = selected.borrowBook(bookOpt.get());
        messageLabel.setText(success ? "Book borrowed." : "Could not borrow (unavailable or limit reached).");
        refreshTable();
    }

    @FXML
    public void handleReturn() {
        Member selected = membersTable.getSelectionModel().getSelectedItem();
        String isbn = isbnField.getText().trim();

        if (selected == null) {
            messageLabel.setText("Select a member first.");
            return;
        }
        Optional<Book> bookOpt = library.findBookByIsbn(isbn);
        if (bookOpt.isEmpty()) {
            messageLabel.setText("No book with that ISBN.");
            return;
        }
        boolean success = selected.returnBook(bookOpt.get());
        messageLabel.setText(success ? "Book returned." : "That member hasn't borrowed this book.");
        refreshTable();
    }

    @FXML
    public void goBack() throws IOException {
        MainApp.switchScene("dashboard.fxml", 700, 480);
    }
}
