package com.library.controller;

import com.library.MainApp;
import com.library.model.Book;
import com.library.service.Library;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class BookController {

    @FXML private TableView<Book> booksTable;
    @FXML private TableColumn<Book, String> isbnColumn;
    @FXML private TableColumn<Book, String> titleColumn;
    @FXML private TableColumn<Book, String> authorColumn;
    @FXML private TableColumn<Book, String> statusColumn;

    @FXML private TextField isbnField;
    @FXML private TextField titleField;
    @FXML private TextField authorField;
    @FXML private Label messageLabel;

    private final Library library = Library.getInstance();
    private ObservableList<Book> bookData;

    @FXML
    public void initialize() {
        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        refreshTable();
    }

    private void refreshTable() {
        bookData = FXCollections.observableArrayList(library.getBooks());
        booksTable.setItems(bookData);
    }

    @FXML
    public void handleAddBook() {
        String isbn = isbnField.getText().trim();
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();

        if (isbn.isEmpty() || title.isEmpty() || author.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        library.addBook(new Book(isbn, title, author));
        refreshTable();
        isbnField.clear();
        titleField.clear();
        authorField.clear();
        messageLabel.setText("Book added.");
    }

    @FXML
    public void handleRemoveSelected() {
        Book selected = booksTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("Select a book to remove.");
            return;
        }
        library.removeBook(selected.getIsbn());
        refreshTable();
        messageLabel.setText("Book removed.");
    }

    @FXML
    public void handleToggleStatus() {
        Book selected = booksTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            messageLabel.setText("Select a book first.");
            return;
        }
        if (selected.isAvailable()) {
            selected.markBorrowed();
        } else {
            selected.markAvailable();
        }
        refreshTable();
    }

    @FXML
    public void goBack() throws IOException {
        MainApp.switchScene("dashboard.fxml", 700, 480);
    }
}
