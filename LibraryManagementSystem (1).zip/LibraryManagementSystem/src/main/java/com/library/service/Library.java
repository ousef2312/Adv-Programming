package com.library.service;

import com.library.model.Book;
import com.library.model.Member;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Central service class that owns and manages all books and members.
 * Demonstrates ENCAPSULATION: the raw lists are private; everything
 * outside this class must go through its public methods.
 *
 * Implemented as a simple singleton so every controller/screen shares
 * the same in-memory state during the app's lifetime.
 */
public class Library {

    private static final Library INSTANCE = new Library();

    private final List<Book> books = new ArrayList<>();
    private final List<Member> members = new ArrayList<>();

    private Library() {
        seedData();
    }

    public static Library getInstance() {
        return INSTANCE;
    }

    private void seedData() {
        books.add(new Book("978-0132350884", "Clean Code", "Robert C. Martin"));
        books.add(new Book("978-0596007126", "Head First Design Patterns", "Freeman & Robson"));
        books.add(new Book("978-0134685991", "Effective Java", "Joshua Bloch"));
        books.add(new Book("978-1491950357", "Building Microservices", "Sam Newman"));

        members.add(new Member("M001", "Ahmed Yousef", "ahmed@example.com"));
        members.add(new Member("M002", "Sara Ali", "sara@example.com"));
    }

    // ----- Book operations -----

    public List<Book> getBooks() {
        return books;
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public boolean removeBook(String isbn) {
        return books.removeIf(b -> b.getIsbn().equals(isbn));
    }

    public Optional<Book> findBookByIsbn(String isbn) {
        return books.stream().filter(b -> b.getIsbn().equals(isbn)).findFirst();
    }

    // ----- Member operations -----

    public List<Member> getMembers() {
        return members;
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public boolean removeMember(String id) {
        return members.removeIf(m -> m.getId().equals(id));
    }

    public Optional<Member> findMemberById(String id) {
        return members.stream().filter(m -> m.getId().equals(id)).findFirst();
    }
}
