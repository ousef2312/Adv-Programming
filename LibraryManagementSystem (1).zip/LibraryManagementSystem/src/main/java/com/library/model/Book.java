package com.library.model;

/**
 * Represents a book in the library catalog.
 * Demonstrates ENCAPSULATION: internal status is only changed through
 * controlled methods (markBorrowed / markAvailable).
 */
public class Book {

    private String isbn;
    private String title;
    private String author;
    private BookStatus status;

    public Book(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.status = BookStatus.AVAILABLE;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public BookStatus getStatus() {
        return status;
    }

    public boolean isAvailable() {
        return status == BookStatus.AVAILABLE;
    }

    public void markBorrowed() {
        this.status = BookStatus.BORROWED;
    }

    public void markAvailable() {
        this.status = BookStatus.AVAILABLE;
    }

    @Override
    public String toString() {
        return title + " by " + author + " [" + status + "]";
    }
}
