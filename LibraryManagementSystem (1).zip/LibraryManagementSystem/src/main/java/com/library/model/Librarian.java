package com.library.model;

/**
 * A librarian who manages the catalog rather than borrowing books.
 * Demonstrates INHERITANCE and POLYMORPHISM: role() behaves
 * differently from Member.role() even though both extend Person.
 */
public class Librarian extends Person {

    private String staffCode;

    public Librarian(String id, String name, String email, String staffCode) {
        super(id, name, email);
        this.staffCode = staffCode;
    }

    public String getStaffCode() {
        return staffCode;
    }

    public void setStaffCode(String staffCode) {
        this.staffCode = staffCode;
    }

    @Override
    public String role() {
        return "Librarian";
    }
}
