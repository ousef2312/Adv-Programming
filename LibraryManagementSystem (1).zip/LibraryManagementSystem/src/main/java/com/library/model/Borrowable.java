package com.library.model;

/**
 * Interface describing an entity capable of borrowing books.
 * Demonstrates ABSTRACTION: exposes only the actions available,
 * hiding how the borrowing/returning is actually tracked.
 */
public interface Borrowable {
    boolean borrowBook(Book book);
    boolean returnBook(Book book);
    int getBorrowedCount();
}
