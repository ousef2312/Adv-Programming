package com.library.model;

/**
 * Abstract base class representing any person in the library system.
 * Demonstrates ABSTRACTION: subclasses must define their own role().
 * Demonstrates ENCAPSULATION: fields are private, accessed via getters/setters.
 */
public abstract class Person {

    private String id;
    private String name;
    private String email;

    public Person(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Abstract method - every concrete subclass must describe its own role.
     * This is the core of the abstraction requirement.
     */
    public abstract String role();

    @Override
    public String toString() {
        return name + " (" + role() + ")";
    }
}
