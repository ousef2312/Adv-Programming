package com.library.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A library member who can borrow books.
 * Demonstrates INHERITANCE (extends Person) and POLYMORPHISM
 * (overrides role(), implements Borrowable differently from any
 * other class that might implement it).
 */
public class Member extends Person implements Borrowable {

    private static final int MAX_BOOKS = 3;
    private final List<Book> borrowedBooks = new ArrayList<>();

    public Member(String id, String name, String email) {
        super(id, name, email);
    }

    @Override
    public String role() {
        return "Member";
    }

    @Override
    public boolean borrowBook(Book book) {
        if (!book.isAvailable() || borrowedBooks.size() >= MAX_BOOKS) {
            return false;
        }
        book.markBorrowed();
        borrowedBooks.add(book);
        return true;
    }

    @Override
    public boolean returnBook(Book book) {
        if (!borrowedBooks.contains(book)) {
            return false;
        }
        book.markAvailable();
        borrowedBooks.remove(book);
        return true;
    }

    @Override
    public int getBorrowedCount() {
        return borrowedBooks.size();
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }
}
