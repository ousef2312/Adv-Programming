# Library Management System (JavaFX)

CCS2304 — Advanced Programming Applications — 12th Project

A small library management app with a login screen, a dashboard, and
two management screens (Books, Members), built with JavaFX + FXML and
Maven.

## How to run

Requirements: JDK 17+ and Maven.

```
mvn clean javafx:run
```

Login with the demo account:
- Username: `admin`
- Password: `admin`

## Screens

1. **Login** — simple credential check before entering the app.
2. **Dashboard** — shows a quick summary and links to the two
   management screens.
3. **Book Management** — table of all books; add a book, remove a
   selected book, toggle its borrowed/available status.
4. **Member Management** — table of all members; add a member, remove
   a member, and borrow/return a book by ISBN for the selected member.

## OOP concepts (see `uml_diagram.png`)

- **Abstraction** — `Person` is an abstract class (`role()` is
  abstract); `Borrowable` is an interface describing the borrowing
  contract without exposing how it's implemented.
- **Encapsulation** — all model fields are `private` with controlled
  getters/setters; `Library` hides its internal `List<Book>` /
  `List<Member>` behind public methods (`addBook`, `removeBook`,
  `findBookByIsbn`, ...).
- **Inheritance** — `Member` and `Librarian` both extend `Person`.
- **Polymorphism** — `Member.role()` and `Librarian.role()` override
  `Person.role()` differently; `Member` implements `Borrowable`.

## Project structure

```
src/main/java/com/library/
  MainApp.java                 application entry point / scene switcher
  model/Person.java            abstract base class
  model/Member.java            extends Person, implements Borrowable
  model/Librarian.java         extends Person
  model/Book.java
  model/BookStatus.java        enum
  model/Borrowable.java        interface
  service/Library.java         central data manager (singleton)
  controller/LoginController.java
  controller/DashboardController.java
  controller/BookController.java
  controller/MemberController.java

src/main/resources/com/library/
  login.fxml
  dashboard.fxml
  books.fxml
  members.fxml
  style.css
```
